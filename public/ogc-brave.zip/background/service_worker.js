/* Background service worker — dispatches recognized gestures.
 * Uses the single JS recognizer (lib/recognizer.js) + lib/matcher.js, a fuzzy matcher so users
 * don't have to draw the exact canonical sequence.
 *
 * Chargé en script CLASSIQUE (pas un module ES) pour rester compatible
 * avec Firefox MV3 event-pages (qui n'acceptent pas toujours
 * "type":"module"), notamment sur macOS. Les dépendances sont chargées
 * via importScripts() côté Chromium (service worker) et via la liste
 * background.scripts côté Firefox (event page).
 */
if (typeof importScripts === "function" && !globalThis.OGC_GESTURES_DATA) {
  try {
    importScripts(
      "../lib/compat.js",
      "../lib/storage.js",
      "../data/gestures.data.js",
      "../lib/recognizer.js",
      "../lib/matcher.js"
    );
  } catch (e) {
    console.error("[OGC] importScripts failed", e);
  }
}
const GESTURES = globalThis.OGC_GESTURES_DATA;
// Moteur unique : la séquence est calculée dans la page par
// lib/recognizer.js. Repli sur le même moteur si un message n'en contient pas.
function sequenceFromPoints(points) {
  const r = new globalThis.OGC_Recognizer();
  for (const [x, y] of points) r.addPoint(x, y);
  return r.sequence();
}

// Détection navigateur — utilisée pour les URLs «accueil navigateur»
// (chaque famille de navigateurs a sa propre page d'accueil interne).
const IS_FIREFOX = !!browser.runtime?.getBrowserInfo;
// Détection Android (Fenix) : `browser.runtime.getPlatformInfo` est async
// mais l'`os` est figé pour la durée de vie de l'event-page. On le cache
// au plus tôt pour gates synchrones.
let IS_ANDROID = false;
browser.runtime.getPlatformInfo?.().then((p) => { IS_ANDROID = p?.os === "android"; }).catch(() => {});
const HOME_RETURN_URL = new Map();
function browserHomeUrl() {
  if (IS_FIREFOX) return "about:home";
  // Chromium (Chrome, Edge, Opera, Brave) : la page d'accueil interne
  // est la nouvelle page d'onglet.
  return "chrome://newtab/";
}

const { OGC_VOCABULARY, ENTRY_BY_ACTION, dashifySeq, findVocab } = globalThis.OGC_MATCHER;

const DEFAULT_SETTINGS = {
  enabled: true, button: 2, trails: true, tooltips: true, sensitivity: 24,
  repeatEnabled: true, voice: false
};

let SETTINGS = { ...DEFAULT_SETTINGS };
let CUSTOM_VOCAB = {}; // sequence -> entry (issu des gestes personnalisés)

async function refreshSettings() {
  const { settings } = await browser.storage.local.get("settings");
  SETTINGS = { ...DEFAULT_SETTINGS, ...(settings || {}) };
}
async function refreshCustom() {
  const customGestures = await OGCStore.getCustom();
  const next = {};
  for (const [actionId, seq] of Object.entries(customGestures || {})) {
    const entry = ENTRY_BY_ACTION[actionId];
    if (entry && typeof seq === "string" && seq.length > 0) {
      // Les gestes personnalisés sont stockés au format compact
      // (sans tirets) ; on les dashifie pour matcher les séquences
      // émises par le recognizer JS.
      next[seq.indexOf("-") >= 0 ? seq : dashifySeq(seq)] = entry;
    }
  }
  CUSTOM_VOCAB = next;
}
refreshSettings();
refreshCustom();
browser.storage.onChanged.addListener((changes) => {
  if (changes.settings) refreshSettings();
  if (changes.customGestures) refreshCustom();
});

browser.runtime.onInstalled.addListener(async () => {
  const { settings } = await browser.storage.local.get("settings");
  if (!settings) await browser.storage.local.set({ settings: DEFAULT_SETTINGS });
});

// Sur Firefox Android, le popup n'est pas affiché : un tap sur l'icône
// déclenche `action.onClicked` que l'on redirige vers la page d'options
// (Préférences) dans un nouvel onglet.
browser.action?.onClicked?.addListener(async () => {
  if (!IS_ANDROID) return; // sur desktop, le popup s'affiche normalement
  try {
    const url = browser.runtime.getURL("options/options.html");
    await browser.tabs.create({ url });
  } catch (e) { console.warn("[OGC] open options failed", e); }
});

/* ---------- détection du lecteur PDF intégré de Firefox ----------
 * Sur Firefox, le visualiseur PDF interne (pdf.js) s'exécute dans un
 * contexte privilégié où les extensions ne peuvent injecter aucun content
 * script : aucun geste ne peut donc y être reconnu. On le détecte au
 * chargement de l'onglet et on prévient l'utilisateur via une notification.
 */
if (IS_FIREFOX) {
  const NOTIFIED = new Set();
  browser.tabs.onUpdated.addListener(async (tabId, info, tab) => {
    if (info.status !== "complete") return;
    const url = tab?.url || "";
    if (!/\.pdf(\?|#|$)/i.test(url) && !/^file:.+\.pdf/i.test(url)) return;
    // Ping le content script : s'il répond, c'est qu'on n'est PAS dans
    // pdf.js (PDF servi en plugin tiers, viewer custom…) — rien à signaler.
    let alive = false;
    try {
      const r = await Promise.race([
        browser.tabs.sendMessage(tabId, { type: "ogc.pingLongPress" }),
        new Promise((res) => setTimeout(() => res(null), 800))
      ]);
      alive = !!r;
    } catch {}
    if (alive) return;
    if (NOTIFIED.has(tabId)) return;
    NOTIFIED.add(tabId);
    try {
      await browser.notifications.create("ogc-pdfjs-" + tabId, {
        type: "basic",
        iconUrl: "icons/ogc-48.png",
        title: "Orange Gesture Control",
        message: "Le lecteur PDF intégré de Firefox n'accepte aucune extension : les gestes ne seront pas fonctionnels sur cette page."
      });
    } catch {}
  });
  browser.tabs.onRemoved?.addListener((tabId) => NOTIFIED.delete(tabId));
}

/* ---------- actions ---------- */
const ACTIONS = {
  "page.back":      async (tab) => navigateAndAdopt(tab, () => browser.tabs.goBack(tab.id)),
  "page.forward":   async (tab) => navigateForward(tab),
  "scroll.up":      async (tab, ctx) => {
    return contextualScroll(tab, ctx, "up", IS_ANDROID ? "down" : "up");
  },
  "scroll.down":    async (tab, ctx) => {
    return contextualScroll(tab, ctx, "down", IS_ANDROID ? "up" : "down");
  },
  "page.top":       async (tab) => scrollExtreme(tab, IS_ANDROID ? "bottom" : "top"),
  "page.bottom":    async (tab) => scrollExtreme(tab, IS_ANDROID ? "top" : "bottom"),
  "site.home":      async (tab, ctx) => {
    if (ctx?.longPress) {
      let url = browserHomeUrl();
      try {
        const hp = await browser.browserSettings?.homepageOverride?.get?.({});
        if (hp?.value) url = String(hp.value).split("|")[0].trim() || url;
      } catch {}
      try { return await browser.tabs.update(tab.id, { url }); }
      catch { return browser.tabs.create({ url }); }
    }
    if (tab.id != null && tab.url) HOME_RETURN_URL.set(tab.id, tab.url);
    return browser.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { window.location.href = window.location.origin + "/"; }
    });
  },
  "search.web":     async (tab, ctx) => {
    if (ctx?.longPress) {
      // "Rechercher dans la page" : ouvre une mini barre de recherche
      // injectée dans la page (équivalent fonctionnel de Ctrl+F).
      let query = (ctx?.selection ?? "").trim();
      if (!query) {
        try {
          const r = await browser.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => (window.getSelection?.()?.toString() || "").trim()
          });
          query = (r?.[0]?.result || "").trim();
        } catch {}
      }
      try {
        await browser.scripting.executeScript({
          target: { tabId: tab.id },
          func: openInPageFind,
          args: [query]
        });
      } catch (e) { console.warn("[OGC] in-page find failed", e); }
      // En complément, on tente aussi l'API native find/highlight si dispo.
      if (query) {
        try {
          await browser.find.find(query, { tabId: tab.id, caseSensitive: false });
          await browser.find.highlightResults({ tabId: tab.id });
        } catch {}
      }
      return;
    }
    const q = ctx?.selection?.trim();
    const url = q
      ? "https://www.google.com/search?q=" + encodeURIComponent(q)
      : "https://www.google.com/";
    return browser.tabs.create({ url });
  },
  "help.toggle":    async (tab) => {
    // Firefox MV3 : sidebarAction.open/toggle exige une activation utilisateur,
    // perdue dans les handlers de messages. Chromium n'expose pas
    // sidebarAction du tout — on tente sidePanel.open(), puis on bascule sur
    // un panneau injecté côté page (même contenu, dans une iframe).
    const sa = browser.sidebarAction;
    try {
      if (sa && typeof sa.toggle === "function") { await sa.toggle(); return; }
      if (sa && typeof sa.open === "function") { await sa.open(); return; }
    } catch (e) { /* fallback injecté ci-dessous */ }
    try {
      const sp = globalThis.chrome?.sidePanel || browser.sidePanel;
      if (sp?.open) { await sp.open({ windowId: tab.windowId, tabId: tab.id }); return; }
    } catch (e) { /* fallback injecté ci-dessous */ }
    try { await browser.tabs.sendMessage(tab.id, { type: "ogc.toggleHelpPanel" }); }
    catch (e) { console.warn("[OGC] help.toggle fallback failed", e); }
  },
  "tab.new":        async (tab, ctx) => {
    const opts = {};
    if (ctx?.linkHref) opts.url = ctx.linkHref;
    return browser.tabs.create(opts);
  },
  "tab.next":       async (tab) => cycleTab(tab, +1),
  "tab.prev":       async (tab) => cycleTab(tab, -1),
  "tab.close":      async (tab) => {
    // On bascule d'abord vers l'onglet voisin pour pouvoir y faire parvenir
    // le retour visuel/vocal (l'onglet courant est sur le point d'être
    // détruit, son content script ne pourra ni afficher ni vocaliser).
    let nextTab = null;
    try {
      const tabs = await browser.tabs.query({ windowId: tab.windowId });
      const sorted = tabs.sort((a, b) => a.index - b.index);
      const i = sorted.findIndex((t) => t.id === tab.id);
      nextTab = sorted[i + 1] || sorted[i - 1] || null;
    } catch {}
    if (nextTab) {
      try { await browser.tabs.update(nextTab.id, { active: true }); } catch {}
      try {
        await browser.tabs.sendMessage(nextTab.id, {
          type: "ogc.feedback",
          label: "Fermer onglet",
          long: false,
          voice: !!SETTINGS.voice
        });
      } catch {}
    }
    await browser.tabs.remove(tab.id);
    if (nextTab) {
      try { await browser.tabs.sendMessage(nextTab.id, { type: "ogc.adoptLongPress" }); } catch {}
      return { pressTabId: nextTab.id, skipFeedback: true };
    }
    return false;
  },
  "window.maximize":async () => cycleWindowState(+1),
  "window.minimize":async () => cycleWindowState(-1),
  "zoom.in":        async (tab) => {
    if (IS_ANDROID) return androidUnavailable(tab);
    return zoomBy(tab, +0.1);
  },
  "zoom.out":       async (tab) => {
    if (IS_ANDROID) return androidUnavailable(tab);
    return zoomBy(tab, -0.1);
  },
  "bookmarks.add":  async (tab) => {
    try {
      const create = { title: tab.title, url: tab.url };
      // Fenix exige `parentId` : `bookmarks.create` sans parent échoue
      // silencieusement. On vise le dossier "Mobile bookmarks", puis à
      // défaut le premier dossier racine.
      if (IS_ANDROID) {
        try {
          const tree = await browser.bookmarks.getTree();
          const root = tree?.[0];
          const folders = (root?.children || []).filter((c) => !c.url);
          const mobile = folders.find((c) => /mobile/i.test(c.id) || /mobile/i.test(c.title))
                      || folders[0];
          if (mobile?.id) create.parentId = mobile.id;
        } catch {}
      }
      await browser.bookmarks.create(create);
      if (IS_ANDROID) {
        browser.notifications?.create?.({
          type: "basic",
          iconUrl: "icons/ogc-48.png",
          title: "Favoris",
          message: "Page ajoutée aux favoris."
        });
      }
    } catch (e) {
      browser.notifications?.create?.({
        type: "basic",
        iconUrl: "icons/ogc-48.png",
        title: "Favoris",
        message: "Ajout impossible : " + (e?.message || e)
      });
    }
  },
  "page.saveAs":    async (tab, ctx) => {
    const url = ctx?.linkHref ?? ctx?.imageSrc ?? tab.url;
    if (!url || /^(about:|moz-extension:|chrome:)/i.test(url)) {
      return browser.notifications?.create?.({
        type: "basic",
        iconUrl: "icons/ogc-48.png",
        title: "Enregistrer sous…",
        message: "Cette page n'est pas téléchargeable."
      });
    }
    try {
      // Fenix ne supporte pas `saveAs:true` (pas de boîte de dialogue) :
      // on demande un téléchargement direct sur Android.
      const opts = IS_ANDROID ? { url } : { url, saveAs: true };
      await browser.downloads.download(opts);
    } catch (e) {
      console.warn("[OGC] download failed", e);
      browser.notifications?.create?.({
        type: "basic",
        iconUrl: "icons/ogc-48.png",
        title: "Enregistrer sous…",
        message: "Téléchargement impossible : " + (e?.message || e)
      });
    }
  },
  /* Élément suivant / précédent : déplace le focus sur l'élément focusable
   * suivant ou précédent dans le DOM de l'onglet actif (équivalent Tab
   * ou Shift+Tab). Réalisé via injection — l'extension ne peut pas
   * envoyer une vraie touche Tab système. */
  "element.next":   async (tab) => focusInTab(tab, "next"),
  "element.prev":   async (tab) => focusInTab(tab, "prev"),
  /* Valider : équivalent Entrée — délégué au content script qui connaît
   * l'élément focusé AVANT que le clic-geste ne déplace ce focus vers
   * <body>. */
  "element.activate": async (tab) => focusInTab(tab, "activate")
};

// Délègue la manipulation du focus au content script de l'onglet : il a
// mémorisé l'élément actif AU moment du pointerdown (avant que le clic du
// geste ne déplace ce focus vers <body>), et peut donc reprendre la
// progression Tab/Shift+Tab au bon endroit, y compris en répétition.
async function focusInTab(tab, kind) {
  try {
    await browser.tabs.sendMessage(tab.id, { type: "ogc.focusAction", kind });
  } catch (e) { /* onglet sans content script */ }
}


async function cycleTab(tab, delta) {
  // Sur Fenix, la notion de "currentWindow" est inopérante : on liste
  // tous les onglets puis on filtre sur `windowId` du tab d'origine si
  // celui-ci est défini.
  let tabs = await browser.tabs.query(IS_ANDROID ? {} : { currentWindow: true });
  if (IS_ANDROID && tab.windowId != null) {
    tabs = tabs.filter((t) => t.windowId === tab.windowId);
  }
  const sorted = tabs.sort((a, b) => a.index - b.index);
  if (sorted.length < 2) return false;
  const i = sorted.findIndex((t) => t.id === tab.id);
  if (i < 0) return false;
  const next = sorted[(i + delta + sorted.length) % sorted.length];
  if (!next || next.id === tab.id) return false;
  await browser.tabs.update(next.id, { active: true });
  try { await browser.tabs.sendMessage(next.id, { type: "ogc.adoptLongPress" }); } catch {}
  return { pressTabId: next.id };
}

function waitTabComplete(tabId, timeoutMs = 4000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      try { browser.tabs.onUpdated.removeListener(listener); } catch {}
      clearTimeout(timer);
      resolve(ok);
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") finish(true);
    };
    const timer = setTimeout(() => finish(false), timeoutMs);
    try { browser.tabs.onUpdated.addListener(listener); } catch { finish(false); }
  });
}

async function navigateAndAdopt(tab, navFn) {
  try { await navFn(); }
  catch { return false; }
  await waitTabComplete(tab.id);
  // Petite marge pour laisser le content script se réinstaller.
  await new Promise((r) => setTimeout(r, 60));
  try { await browser.tabs.sendMessage(tab.id, { type: "ogc.adoptLongPress" }); } catch {}
  return { pressTabId: tab.id };
}

async function navigateForward(tab) {
  const before = tab.url || "";
  const result = await navigateAndAdopt(tab, () => browser.tabs.goForward(tab.id));
  let after = before;
  try { after = (await browser.tabs.get(tab.id))?.url || before; } catch {}
  if (result !== false && after !== before) {
    HOME_RETURN_URL.delete(tab.id);
    return result;
  }
  const remembered = HOME_RETURN_URL.get(tab.id);
  if (!remembered) return result;
  HOME_RETURN_URL.delete(tab.id);
  try {
    await browser.tabs.update(tab.id, { url: remembered });
    await waitTabComplete(tab.id);
    return { pressTabId: tab.id };
  } catch { return false; }
}

async function scrollExtreme(tab, where) {
  // allFrames: true permet de défiler aussi à l'intérieur des iframes
  // (lecteur PDF SharePoint, pdf.js embarqué, etc.). On vise au passage
  // l'élément interne le plus haut qui soit réellement scrollable, car
  // sur certains visualiseurs PDF ce n'est ni window ni document.body.
  await browser.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: (w) => {
      const top = w === "top";
      // 1) défile la fenêtre
      try {
        window.scrollTo({ top: top ? 0 : document.documentElement.scrollHeight, behavior: "smooth" });
      } catch {}
      // 2) défile aussi le plus grand conteneur scrollable interne
      let best = null, bestArea = 0;
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length && i < 4000; i++) {
        const el = all[i];
        if (el.scrollHeight - el.clientHeight < 40) continue;
        const cs = getComputedStyle(el);
        if (!/(auto|scroll|overlay)/.test(cs.overflowY)) continue;
        const area = el.clientWidth * el.clientHeight;
        if (area > bestArea) { best = el; bestArea = area; }
      }
      if (best) {
        try { best.scrollTo({ top: top ? 0 : best.scrollHeight, behavior: "smooth" }); }
        catch { best.scrollTop = top ? 0 : best.scrollHeight; }
      }
    },
    args: [where]
  }).catch(() => {});
}

async function contextualScroll(tab, ctx, dir, scrollDir = dir) {
  if (dir === "up" && ctx?.selection) {
    return browser.scripting.executeScript({
      target: { tabId: tab.id },
      func: async (text) => {
        try { await navigator.clipboard.writeText(text); }
        catch { document.execCommand("copy"); }
      },
      args: [ctx.selection]
    });
  }
  if (dir === "down" && ctx?.inEditable) {
    return browser.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const el = document.activeElement;
        let text = "";
        try { text = await navigator.clipboard.readText(); }
        catch { text = ""; }
        if (!text) { document.execCommand("paste"); return; }
        if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) {
          const start = el.selectionStart ?? el.value.length;
          const end   = el.selectionEnd   ?? el.value.length;
          el.value = el.value.slice(0, start) + text + el.value.slice(end);
          const pos = start + text.length;
          el.selectionStart = el.selectionEnd = pos;
          el.dispatchEvent(new Event("input", { bubbles: true }));
        } else if (el && el.isContentEditable) {
          document.execCommand("insertText", false, text);
        }
      }
    });
  }
  const step = scrollDir === "up" ? -300 : 300;
  return browser.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: (s) => {
      // Défile la fenêtre…
      try { window.scrollBy({ top: s, behavior: "smooth" }); } catch {}
      // …et le plus grand conteneur scrollable interne (lecteurs PDF
      // SharePoint, pdf.js, viewers custom où window n'est pas scrollable).
      let best = null, bestArea = 0;
      const all = document.querySelectorAll("*");
      for (let i = 0; i < all.length && i < 4000; i++) {
        const el = all[i];
        if (el.scrollHeight - el.clientHeight < 40) continue;
        const cs = getComputedStyle(el);
        if (!/(auto|scroll|overlay)/.test(cs.overflowY)) continue;
        const area = el.clientWidth * el.clientHeight;
        if (area > bestArea) { best = el; bestArea = area; }
      }
      if (best) {
        try { best.scrollBy({ top: s, behavior: "smooth" }); }
        catch { best.scrollTop += s; }
      }
    },
    args: [step]
  }).catch(() => {});
}

async function zoomBy(tab, delta) {
  const z = await browser.tabs.getZoom(tab.id);
  await browser.tabs.setZoom(tab.id, Math.max(0.3, Math.min(3, z + delta)));
}

const WIN_STATES = ["minimized", "normal", "maximized", "fullscreen"];
async function androidUnavailable(tab) {
  try {
    browser.tabs.sendMessage(tab.id, {
      type: "ogc.feedback",
      label: "Indisponible sur Android",
      long: false,
      voice: !!SETTINGS.voice
    }).catch(() => {});
  } catch {}
  return false;
}

async function cycleWindowState(delta) {
  // Android (Fenix) n'a pas l'API browser.windows : on signale poliment
  // que la fonction n'est pas applicable et on arrête toute répétition.
  if (IS_ANDROID || !browser.windows) {
    try {
      const [active] = await browser.tabs.query({ active: true, currentWindow: true });
      if (active) {
        browser.tabs.sendMessage(active.id, {
          type: "ogc.feedback",
          label: "Indisponible sur Android",
          long: false,
          voice: !!SETTINGS.voice
        }).catch(() => {});
      }
    } catch {}
    return false;
  }
  const win = await browser.windows.getCurrent();
  const i = WIN_STATES.indexOf(win.state);
  // Clamp aux extrémités : on s'arrête à `minimized` ou `fullscreen`.
  const j = Math.max(0, Math.min(WIN_STATES.length - 1, i + delta));
  if (j === i) return false; // signale au répéteur qu'il faut s'arrêter
  await browser.windows.update(win.id, { state: WIN_STATES[j] });
  // Retourne false aussi si on vient d'atteindre une extrémité, pour
  // que la prochaine itération soit évitée.
  if (j === 0 || j === WIN_STATES.length - 1) return false;
  return true;
}

/* ---------- background-driven repetition ----------
 * Pour fiabiliser la répétition au-delà des navigations (page.back, tab.close,
 * tab.next), le background pilote la boucle : après chaque action, on attend
 * REPEAT_MS puis on demande à l'onglet actif si l'utilisateur maintient
 * toujours l'appui. Si oui, on répète. Sinon, on s'arrête.
 */
const REPEAT_MS = 650;
let activeRepeat = null;
function stopRepeat() {
  if (activeRepeat) {
    if (activeRepeat.timer) clearTimeout(activeRepeat.timer);
    activeRepeat = null;
  }
}

async function pingLongPress(tabId) {
  try {
    const r = await browser.tabs.sendMessage(tabId, { type: "ogc.pingLongPress" });
    return !!r?.active;
  } catch { return false; }
}

function isNavigationRepeatAction(action) {
  return action === "page.back" || action === "page.forward" ||
    action === "tab.next" || action === "tab.prev" || action === "tab.close";
}

async function getCurrentTab(originTab) {
  try {
    const wid = originTab?.windowId;
    const tabs = await browser.tabs.query({ active: true, windowId: wid });
    return tabs[0] || originTab;
  } catch { return originTab; }
}

function scheduleRepeat(entry, handler, originTab, ctx, token) {
  if (!activeRepeat || activeRepeat.token !== token) return;
  activeRepeat.timer = setTimeout(async () => {
    if (!activeRepeat || activeRepeat.token !== token) return;
    const target = isNavigationRepeatAction(entry.action) ? await getCurrentTab(originTab) : originTab;
    if (!activeRepeat || activeRepeat.token !== token) return;
    if (!target) { stopRepeat(); return; }
    const stillPressing = await pingLongPress(activeRepeat.pressTabId);
    if (!stillPressing) { stopRepeat(); return; }
    let cont = true;
    try {
      const r = await handler(target, ctx);
      if (!activeRepeat || activeRepeat.token !== token) return;
      if (r === false) cont = false;
      else if (r?.pressTabId && activeRepeat?.token === token) activeRepeat.pressTabId = r.pressTabId;
    } catch (err) { console.warn("[OGC] repeat failed", err); }
    if (!cont) { stopRepeat(); return; }
    scheduleRepeat(entry, handler, originTab, ctx, token);
  }, REPEAT_MS);
}

browser.runtime.onMessage.addListener(async (msg, sender) => {
  const tab = sender.tab;
  if (msg?.type === "ogc.runAction" && typeof msg.action === "string") {
    // Invoqué depuis la popup pour rejouer une action sans geste.
    try {
      const [active] = await browser.tabs.query({ active: true, currentWindow: true });
      if (!active) return;
      const handler = ACTIONS[msg.action];
      if (handler) await handler(active, {});
    } catch (e) { console.warn("[OGC] runAction failed", e); }
    return;
  }
  if (!tab) return;
  if (msg?.type === "ogc.repeatStop") { stopRepeat(); return; }
  if (msg?.type !== "ogc.stroke" || !Array.isArray(msg.points)) return;

  const ctx = msg.context ?? {};
  // Any new stroke cancels a pending repeat.
  stopRepeat();
  const sequence = typeof msg.sequence === "string" ? msg.sequence : sequenceFromPoints(msg.points);
  // Ordre conservé : exacte, personnalisée, puis approchée.
  const entry = OGC_VOCABULARY[sequence] || CUSTOM_VOCAB[sequence] || findVocab(sequence);
  if (!entry) return;

  const handler = ACTIONS[entry.action];
  if (!handler) return;

  // Send tooltip feedback to the page (FR label).
  // Étiquette contextuelle : certains gestes changent de sens selon le
  // contexte (sélection de texte, champ de saisie). On annonce alors
  // l'action réellement effectuée plutôt que le libellé générique.
  let labelText = ctx.longPress && entry.longLabel ? entry.longLabel : entry.label;
  if (!ctx.longPress) {
    if (entry.action === "scroll.up" && (ctx.selection || "").trim()) {
      labelText = "Copier";
    } else if (entry.action === "scroll.down" && ctx.inEditable) {
      labelText = "Coller";
    }
  }
  // L'action tab.close gère elle-même son feedback (envoyé à l'onglet
  // voisin, le courant étant détruit). On laisse le handler s'en occuper.
  if (entry.action !== "tab.close") {
    browser.tabs.sendMessage(tab.id, {
      type: "ogc.feedback",
      label: labelText,
      long: !!ctx.longPress,
      voice: !!SETTINGS.voice
    }).catch(() => {});
  }

  let firstResult;
  try { firstResult = await handler(tab, ctx); }
  catch (err) { console.warn("[OGC] action failed", entry.action, sequence, err); }

  // Démarre la boucle de répétition pilotée par le background pour les
  // gestes répétables, sauf si la première exécution a déjà demandé l'arrêt.
  if (ctx.longPress && entry.repeat && firstResult !== false && SETTINGS.repeatEnabled !== false) {
    const token = Symbol("repeat");
    // Pour `tab.close`, l'onglet d'origine vient d'être détruit : le handler
    // renvoie l'id de l'onglet voisin (où le content script a adopté
    // l'appui long). On part de cet id-là pour pinger la suite.
    const initialPressTabId = (firstResult && firstResult.pressTabId) || tab.id;
    activeRepeat = { token, timer: null, pressTabId: initialPressTabId };
    scheduleRepeat(entry, handler, tab, ctx, token);
  }
});

/* ---------- helper injecté pour la recherche dans la page ---------- */
function openInPageFind(initialQuery) {
  try {
    const ID = "__ogc_find_bar__";
    document.getElementById(ID)?.remove();
    const bar = document.createElement("div");
    bar.id = ID;
    bar.style.cssText = [
      "position:fixed", "top:12px", "right:12px", "z-index:2147483647",
      "background:#fff", "color:#111", "border:1px solid #ccc",
      "border-radius:8px", "box-shadow:0 4px 16px rgba(0,0,0,.2)",
      "padding:8px 10px", "font:14px/1.2 system-ui,sans-serif",
      "display:flex", "gap:6px", "align-items:center"
    ].join(";");
    const input = document.createElement("input");
    input.type = "search";
    input.placeholder = "Rechercher dans la page…";
    input.value = initialQuery || "";
    input.style.cssText = "border:1px solid #ccc;border-radius:6px;padding:4px 8px;min-width:220px;font:inherit";
    const prev = document.createElement("button"); prev.textContent = "◀";
    const next = document.createElement("button"); next.textContent = "▶";
    const close = document.createElement("button"); close.textContent = "✕";
    for (const b of [prev, next, close]) {
      b.style.cssText = "border:1px solid #ccc;background:#f4f4f4;border-radius:6px;padding:2px 8px;cursor:pointer;font:inherit";
    }
    const doFind = (forward) => {
      const q = input.value;
      if (!q) return;
      try { window.find(q, false, !forward, true, false, true, false); } catch {}
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); doFind(!e.shiftKey); }
      else if (e.key === "Escape") { e.preventDefault(); bar.remove(); }
    });
    next.addEventListener("click", () => doFind(true));
    prev.addEventListener("click", () => doFind(false));
    close.addEventListener("click", () => bar.remove());
    bar.append(input, prev, next, close);
    document.documentElement.appendChild(bar);
    input.focus(); input.select();
    if (initialQuery) doFind(true);
  } catch (e) { console.warn("[OGC] openInPageFind", e); }
}